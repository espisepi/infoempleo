#utf-8

import os
import urllib
from bs4 import BeautifulSoup
import sqlite3 
import Tkinter
from Tkinter import *
import tkMessageBox
from whoosh.index import create_in,open_dir
from whoosh.fields import Schema, TEXT, KEYWORD
from whoosh.qparser import QueryParser
from bs4 import BeautifulSoup
import BeautifulSoup 
from BeautifulSoup import inicio
from pattern.text.tree import BLUE


dirindex="Index"
top=Tk()

def extraer():
    url = "https://www.infoempleo.com/trabajo/en_sevilla/area-de-empresa_ingenieria-y-produccion//"
    html = urllib.urlopen(url)
    soup = BeautifulSoup(html, 'html.parser')
    print soup
     

def indexar():
    if not os.path.exists(dirindex):
            os.mkdir(dirindex)
    #diccionario_prueba = #{{'Titulo1','Funciones1','Requisitos1','Area1','Categoria1','Vacantes1','Jornada1','Contrato1', 'Retribucion1','Experiencia1'},{'Titulo2','Funciones2','Requisitos2','Area2','Categoria2','Vacantes2','Jornada2','Contrato2', 'Retribucion2', 'Experiencia2'}}
    #lista_completa= scraping("https://www.infoempleo.com/trabajo/en_sevilla/area-de-empresa_ingenieria-y-produccion/")
    lista_completa= inicio()
    ix = create_in(dirindex, schema=get_schema()) #crea el indice y el esquema, que se almacena con el indice (lo que se indexa se puede buscar)
    writer = ix.writer() #'escribe' el indice
    for elemento in lista_completa:
        writer.add_document(titulo=unicode(elemento[0]),funciones = unicode(elemento[1]),requisitos = unicode(elemento[2]),area =unicode(elemento[3]), categoria= unicode(elemento[4]), nvacantes = unicode(elemento[5]), jornada = unicode(elemento[6]), contrato = unicode(elemento[7]), retribucion = unicode(elemento[8]), experiencia=unicode(elemento[9]))
    tkMessageBox.showinfo("Fin de indexado", "Se han indexado "+str(len(lista_completa))+ " trabajos")
            
    writer.commit()
    
def get_schema():
    return Schema(titulo=TEXT(stored=True), funciones=TEXT(stored=True), requisitos=TEXT(stored=True), area=TEXT(stored=True), categoria=TEXT(stored=True), nvacantes=TEXT(stored=True), jornada=TEXT(stored=True), contrato=TEXT(stored=True), retribucion=TEXT(stored=True), experiencia=TEXT(stored=True))



def buscar_titulo():
    def mostrar_lista(event):
        lb.delete(0,END)   
        ix=open_dir(dirindex)  
        with ix.searcher() as searcher:
            query = QueryParser("titulo", ix.schema).parse(unicode(en.get())) 
            results = searcher.search(query)
            for r in results:
                lb.insert(END,r['titulo'])
                lb.insert(END,r['funciones'])
                lb.insert(END,r['requisitos'])
                lb.insert(END,r['area'])
                lb.insert(END,r['categoria'])
                lb.insert(END,r['nvacantes'])
                #lb.insert(END,r['jornada'])
                #lb.insert(END,r['contrato'])
                #lb.insert(END,r['retribucion'])
                #lb.insert(END,r['experiencia'])
                lb.insert(END,'')
    v = Toplevel()
    v.title("Busqueda por titulos")
    f =Frame(v)
    f.pack(side=TOP)
    l = Label(f, text="Introduzca el titulo:")
    l.pack(side=LEFT)
    en = Entry(f)
    en.bind("<Return>", mostrar_lista) #cuando haga return se muestre la lista
    en.pack(side=LEFT)
    sc = Scrollbar(v)
    sc.pack(side=RIGHT, fill=Y)
    lb = Listbox(v, yscrollcommand=sc.set, width=150, height=40)
    lb.pack(side=BOTTOM, fill = BOTH)
    sc.config(command = lb.yview) 
    
#===============================================================================
# def buscar_categoria():
#     def mostrar_lista(event):
#         lb.delete(0,END)   
#         ix=open_dir(dirindex)
#         with ix.searcher() as searcher:
#             query = QueryParser("categoria", ix.schema).parse(unicode(en.get())) 
#             results = searcher.search(query)
#             for r in results:
#                 lb.insert(END,r['titulo'])
#                 lb.insert(END,r['funciones'])
#                 lb.insert(END,r['requisitos'])
#                 lb.insert(END,r['area'])
#                 lb.insert(END,r['categoria'])
#                 lb.insert(END,r['nvacantes'])
#                 #lb.insert(END,r['jornada'])
#                 #lb.insert(END,r['contrato'])
#                 #lb.insert(END,r['retribucion'])
#                 #lb.insert(END,r['experiencia'])
#                 lb.insert(END,'')
#     v = Toplevel()
#     v.title("Busqueda por categorias")
#     f =Frame(v)
#     f.pack(side=TOP)
#     l = Label(f, text="Introduzca una categoria:")
#     l.pack(side=LEFT)
#     en = Entry(f)
#     en.bind("<Return>", mostrar_lista) 
#     en.pack(side=LEFT)
#     sc = Scrollbar(v)
#     sc.pack(side=RIGHT, fill=Y)
#     lb = Listbox(v, yscrollcommand=sc.set, width=150, height=40)
#     lb.pack(side=BOTTOM, fill = BOTH)
#     sc.config(command = lb.yview) 
#===============================================================================
    
def buscar_categorias():
    def mostrar_lista(event):
        lb.delete(0,END)   
        ix=open_dir(dirindex)  
        with ix.searcher() as searcher:
            query = QueryParser("categoria", ix.schema).parse(unicode(w.get())) 
            results = searcher.search(query)
            for r in results:
                lb.insert(END,r['titulo'])
                lb.insert(END,r['funciones'])
                lb.insert(END,r['requisitos'])
                lb.insert(END,r['area'])
                lb.insert(END,r['categoria'])
                lb.insert(END,r['nvacantes'])
                lb.insert(END,'')
    v = Toplevel()
    v.title("Busqueda por categoria")
    f =Frame(v)
    f.pack(side=TOP)
    l = Label(f, text="Seleccione la categoria:")
    l.pack(side=LEFT)
    en = Entry(f, width=30)
    en.insert(END,"Seleccione abajo y pulse enter aqui")
    en.bind("<Return>", mostrar_lista) 
    en.pack(side=LEFT)
    lista_completa=inicio()
    categorias=[]
    for factor in lista_completa:
        categoria = factor[4]
        categorias.append(categoria)
    w = Spinbox(v, values=categorias)
    w.pack()
    sc = Scrollbar(v)
    sc.pack(side=RIGHT, fill=Y)
    lb = Listbox(v, yscrollcommand=sc.set, width=150, height=40)
    lb.pack(side=BOTTOM, fill = BOTH)
    sc.config(command = lb.yview) 
    
#===============================================================================
# def buscar_area():
#     def mostrar_lista(event):
#         lb.delete(0,END)   
#         ix=open_dir(dirindex)
#         with ix.searcher() as searcher:
#             query = QueryParser("area", ix.schema).parse(unicode(en.get())) 
#             results = searcher.search(query)
#             for r in results:
#                 lb.insert(END,r['titulo'])
#                 lb.insert(END,r['funciones'])
#                 lb.insert(END,r['requisitos'])
#                 lb.insert(END,r['area'])
#                 lb.insert(END,r['categoria'])
#                 lb.insert(END,r['nvacantes'])
#                 #lb.insert(END,r['jornada'])
#                 #lb.insert(END,r['contrato'])
#                 #lb.insert(END,r['retribucion'])
#                 #lb.insert(END,r['experiencia'])
#                 lb.insert(END,'')
#     v = Toplevel()
#     v.title("Busqueda por area")
#     f =Frame(v)
#     f.pack(side=TOP)
#     l = Label(f, text="Introduzca un area:")
#     l.pack(side=LEFT)
#     en = Entry(f)
#     en.bind("<Return>", mostrar_lista) 
#     en.pack(side=LEFT)
#     sc = Scrollbar(v)
#     sc.pack(side=RIGHT, fill=Y)
#     lb = Listbox(v, yscrollcommand=sc.set, width=150, height=40)
#     lb.pack(side=BOTTOM, fill = BOTH)
#     sc.config(command = lb.yview) 
#===============================================================================
    
def buscar_areas():
    def mostrar_lista(event):
        lb.delete(0,END)   
        ix=open_dir(dirindex)  
        with ix.searcher() as searcher:
            query = QueryParser("area", ix.schema).parse(unicode(w.get())) 
            results = searcher.search(query)
            for r in results:
                lb.insert(END,r['titulo'])
                lb.insert(END,r['funciones'])
                lb.insert(END,r['requisitos'])
                lb.insert(END,r['area'])
                lb.insert(END,r['categoria'])
                lb.insert(END,r['nvacantes'])
                lb.insert(END,'')
    v = Toplevel()
    v.title("Busqueda por area")
    f =Frame(v)
    f.pack(side=TOP)
    l = Label(f, text="Seleccione el area:")
    l.pack(side=LEFT)
    en = Entry(f, width=30)
    en.insert(END,"Seleccione abajo y pulse enter aqui")
    en.bind("<Return>", mostrar_lista) 
    en.pack(side=LEFT)
    lista_completa=inicio()
    areas=[]
    for factor in lista_completa:
        area = factor[3]
        areas.append(area)
    w = Spinbox(v, values=areas)
    w.pack()
    sc = Scrollbar(v)
    sc.pack(side=RIGHT, fill=Y)
    lb = Listbox(v, yscrollcommand=sc.set, width=150, height=40)
    lb.pack(side=BOTTOM, fill = BOTH)
    sc.config(command = lb.yview)


def funcion_salir():
        top.destroy() 


def ventana_principal():
    datos=  Menubutton ( top, text="Inicio", relief=RAISED )
    datos.grid()
    datos.menu  =  Menu ( datos, tearoff = 0 )
    datos["menu"]  =  datos.menu
    
    Indexar  = IntVar()
    Salir = IntVar()

    datos.menu.add_checkbutton ( label="Indexar",
                             variable=Indexar, command=indexar )
    datos.menu.add_checkbutton ( label="Salir",
                             variable=Salir, command=funcion_salir )


    buscar=  Menubutton ( top, text="Buscar", relief=RAISED )
    buscar.grid()
    buscar.menu  =  Menu ( buscar, tearoff = 0 )
    buscar["menu"]  =  buscar.menu

    Titulo  = IntVar()
    Categoria = IntVar()
    Area = IntVar()

    buscar.menu.add_checkbutton ( label="Titulo",
                              variable=Titulo, command= buscar_titulo)
    buscar.menu.add_checkbutton ( label="Categoria",
                              variable=Categoria, command= buscar_categorias )
    buscar.menu.add_checkbutton ( label="Area",
                              variable=Area, command= buscar_areas )


    

    datos.pack()
    buscar.pack()
    top.mainloop()
    
ventana_principal()